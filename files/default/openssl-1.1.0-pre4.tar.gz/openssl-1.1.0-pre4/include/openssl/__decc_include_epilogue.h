/*
 * This file is only used by HP C on VMS, and is included automatically
 * after each header file from this directory
 */

/* restore state.  Must correspond to the save in __decc_include_prologue.h */
#pragma names restore
